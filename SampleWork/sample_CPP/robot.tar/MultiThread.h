#ifdef _MULTI_THREAD_H_
#define _MULTI_THREAD_H_
#include <pthread.h>
#include "Interpreter
class MultiThread
{
public:
    
    void createThread();
};


#endif
