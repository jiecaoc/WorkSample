#ifndef _CONST_
#define _CONST_
const float PI = 3.1415926;
//the number of points in the circle
const int NUM_POINTS = 130;
//const float unitDegree = 0.05f;
//const float unitSpeed = 10.0f;
const int NUM_GOAL_ROBOT = 2;



//const float WIN_WIDTH = 1280.0f;
//const float WIN_HEIGHT = 960.0f;


const float TOT_TIME = 170.0f;




    

    
#endif
