#include "Command.h"

/*
Command::Command()
{
    command = "test";
}
*/
/*
Command::Command(string &cmdName, string &para)
{
    command = cmdName;
    parametersVec.push_back(para);
}
*/
/*
Command::Command(string cmdName, vector<string> & paraVec)
{
    command = cmdName;
    for (unsigned int i = 0; i < paraVec.size(); ++i)
        parametersVec.push_back(paraVec[i]);
}
*/
